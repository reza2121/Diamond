do
local B = {
SudoID = "560741960",
Channel = "@Dieman_Tabchi",
		}
return B
end